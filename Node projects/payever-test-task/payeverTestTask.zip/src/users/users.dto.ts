import {
    User
  } from "./user.entity";
  
  export class CreateUserDto extends User {}